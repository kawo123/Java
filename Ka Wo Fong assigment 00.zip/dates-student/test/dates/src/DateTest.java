package dates.src;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before; 

import dates.src.Date;

public class DateTest {

	private Date date;
	
	@Before
	public void before() {
		date = new Date(12,19,1973);
	}
	
	@Test
	public void testGetYear() {
		assertEquals("The year is reported incorrectly", 1973, date.getYear());
	}

	@Test
	public void testGetMonth() {
		assertEquals("The month is reported incorrectly", 12, date.getMonth());
	}

	@Test
	public void testGetDay() {
		assertEquals("The day is reported incorrectly", 19, date.getDay());
	}

	@Test
	public void testToString() {
		assertEquals("Standard string output not correct", "12/19/1973", date.toString());
	}

	@Test
	public void testlilian() {
		assertEquals("Lilian date conversion not correct", 142876, date.lilian());
	}

	@Test
	public void testIndexDayOfWeek() {
		assertEquals("Day index of week not correct", 3, date.indexDayOfWeek());
	}
	

	
}
