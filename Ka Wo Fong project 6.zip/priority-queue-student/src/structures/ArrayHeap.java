package structures;

import java.util.Comparator;
import java.util.List;
import structures.AbstractArrayHeap;

public class ArrayHeap<P, V> extends AbstractArrayHeap<P, V> 
{

	protected List<Entry<P,V>> list; 
	protected Comparator <P> comparator; 
	
	public ArrayHeap(Comparator<P> comparator) 
	{
		super(comparator);
		list = this.asList(); 
		this.comparator = comparator; 
	}

	@Override
	protected int getLeftChildOf(int index) 
	{
		if (index < 0)
			throw new IndexOutOfBoundsException ("Index must be zero or greater!"); 
		else
			return (index * 2 + 1);
	}

	@Override
	protected int getRightChildOf(int index) 
	{
		if (index < 0)
			throw new IndexOutOfBoundsException ("Index must be zero or greater!"); 
		else
			return (index * 2 + 2);
	}

	@Override
	protected int getParentOf(int index) 
	{
		if (index < 1)
			throw new IndexOutOfBoundsException ("Index must be one or greater!"); 
		else
			return ((index - 1) / 2);
	}

	@Override
	protected void bubbleUp(int index) 
	{
		P current, parent; 
		int hole = index; 
		current = list.get(hole).getPriority(); 
		if (hole == 0)
			parent = list.get(hole).getPriority(); 
		else
			parent = list.get(getParentOf(hole)).getPriority(); 
//		while ((hole > 0) && (((Comparable) current).compareTo(parent) > 0))
		while ((hole > 0) && (comparator.compare(current, parent) > 0))
		{
			this.swap(hole, getParentOf(hole)); 
			hole = this.getParentOf(hole); 
			current = list.get(hole).getPriority(); 
			if (hole == 0)
				parent = list.get(0).getPriority(); 
			else
				parent = list.get(getParentOf(hole)).getPriority();
		}
		

	}

	@Override
	protected void bubbleDown(int index) 
	{
		int newHole = newHole(index); 
		while (newHole != index)
		{
			this.swap(index, newHole);
			index = newHole; 
			newHole = newHole(index);
		}

	}
	
	private int newHole (int index)
	{
		int left = this.getLeftChildOf(index);
		int right = this.getRightChildOf(index);
		P current = list.get(index).getPriority(); 
		if (left > this.size()-1)
			return index; 
		P leftPriority = list.get(left).getPriority(); 
		if (left == this.size()-1)
//			if (((Comparable) current).compareTo(leftPriority) < 0)
			if (comparator.compare(current, leftPriority) < 0)
				return left; 
			else 
				return index; 
		P rightPriority = list.get(right).getPriority(); 
//		if (((Comparable) leftPriority).compareTo(rightPriority) < 0)
		if (comparator.compare(leftPriority, rightPriority) < 0)
//			if (((Comparable) rightPriority).compareTo(current) <= 0)
			if (comparator.compare(rightPriority, current) < 0)
				return index; 
			else 
				return right; 
		else 
//			if (((Comparable) leftPriority).compareTo(current) <= 0)
			if (comparator.compare(leftPriority, current) <= 0)
				return index; 
			else 
				return left;
	}
	

}
