package structures;

import java.util.Deque;
import java.util.Iterator;
import java.util.List;

// Adopted from the PreOrderIterator from Project 5

public class QueueIterator<V> implements Iterator<Entry<Integer, V>> 
{


	private Deque<Entry<Integer, V>> stack; 
	private List<Entry<Integer,V>> list; 
	
	public QueueIterator(ArrayHeap<Integer,V> heap)
	{

		list = heap.asList(); 
		for (int i = 0; i < list.size(); i++)
		{
			stack.push(list.get(i));
		}
	}

	@Override
	public boolean hasNext() 
	{
		return !stack.isEmpty();
	}

	@Override
	public Entry<Integer, V> next() 
	{
		return ( stack.pop() );
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
