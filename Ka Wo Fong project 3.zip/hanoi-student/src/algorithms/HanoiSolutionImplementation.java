package algorithms;

import structures.ListInterface;
import hanoi.HanoiMove;
import hanoi.HanoiSolution;

public class HanoiSolutionImplementation implements HanoiSolution 
{
	int numRings; 
	UnboundList<HanoiMove> listMoves; 
	
	public HanoiSolutionImplementation (int i, ListInterface<HanoiMove> list)
	{
		numRings = i; 
		listMoves = (UnboundList<HanoiMove>) list; 
	}
	
	@Override
	public int getNumberOfRings() 
	{
		return numRings;
	}
	
	@Override
	public ListInterface<HanoiMove> getMoves() 
	{
		
		return listMoves;
	}

}
