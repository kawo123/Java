package algorithms;

public class RecursiveBasicMath implements BasicMath
{
	
	@Override
	public boolean isEven(int val) 
	{
		// TODO Auto-generated method stub
		if (val == 0)
			return true; 
		if (val == 1)
			return false;
		if (val>0) 
			return isEven(val-2);
		else 
			return isEven(val+2);
	}

	@Override
	public boolean isOdd(int val) 
	{
		return !(isEven(val));
	}

	@Override
	public int sumN(int n) 
	{
		if (n < 0)
			throw new IllegalArgumentException("Input must be greater than 0.");
		if (n==0)
			return 0; 
		else 
			return n + sumN(n-1);
	}

	@Override
	public int factorial(int n) 
	{
		if (n < 0)
			throw new IllegalArgumentException("Input must be greater than 0.");
		if (n==0)
			return 1; 
		else 
			return n * factorial(n-1);
	}

	@Override
	public int biPower(int n) 
	{
		// TODO Auto-generated method stub
		if (n < 0)
			throw new IllegalArgumentException("Input must be greater than 0.");
		if (n == 0)
			return 1;
		else 
			return 2*biPower(n-1);
	}

}
