package algorithms;

/* Adopted from Postfix Project 
 * @author Ka Wo Fong
 */


public class LinkedStack<T> 
{

	protected ListNode<T> top;
	protected ListNode<T> node; 
	
	public LinkedStack ()
	{
		top = null;
		node = null; 
	}
	

	public T pop() throws StackUnderflowException 
	{
		node = top; 
		if (isEmpty())
			throw new StackUnderflowException ("Stack is Empty");
		else 
			top = top.getLink(); 
			
		return node.getInfo();
	}


	public T top() throws StackUnderflowException 
	{
		// TODO Auto-generated method stub

		if (isEmpty())
			throw new StackUnderflowException ("Stack is Empty");
		else 
			return top.getInfo();
	}



	public boolean isEmpty() 
	{
		return (top == null);
	}


	public int size() 
	{
		int size = 0; 
		node = top;
		while (node != null)
		{
			size++;
			node = node.getLink();
		}
		return size;
	}


	public void push(T elem) 
	{
		ListNode<T> temp = new ListNode<T> (elem);
		temp.setLink(top); 
		top = temp; 
		
	}
}
