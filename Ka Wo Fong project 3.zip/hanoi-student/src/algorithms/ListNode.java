package algorithms;

public class ListNode<T> 
{
	protected T info;
	protected ListNode<T> node; 
	public ListNode (T elem)
	{
		this.info = elem;
		this.node = null; 
	}
	public T getInfo()
	{
		return info; 
	}
	public ListNode<T> getLink()
	{
		return node; 
	}
	public void setInfo(T elem)
	{
		this.info = elem; 
	}
	public void setLink(ListNode<T> node)
	{
		this.node = node; 
	}
	
}
