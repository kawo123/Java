package algorithms;

import hanoi.HanoiPeg;
import hanoi.HanoiRing;
import hanoi.IllegalHanoiMoveException;

public class HanoiPegImplementation implements HanoiPeg 
{
	protected LinkedStack<HanoiRing> peg;
	
	public HanoiPegImplementation ()
	{
		peg = new LinkedStack<HanoiRing> ();
	}
	
	@Override
	public void addRing(HanoiRing ring) 
	{
		if (ring == null)
			throw new NullPointerException ("Ring has not been set up yet"); 
		if (!(peg.isEmpty()) && ring.getSize() >= peg.top().getSize())
			throw new IllegalHanoiMoveException ("Cannot move a smaller ring on a bigger ring!"); 
		else 
			peg.push(ring); 
	}

	@Override
	public HanoiRing remove() 
	{
		if (peg.isEmpty())
			throw new IllegalHanoiMoveException ("Peg is empty!"); 
		return peg.pop();
	}

	@Override
	public HanoiRing getTopRing() 
	{
		return peg.top();
	}

	@Override
	public boolean hasRings() 
	{
		return !(peg.isEmpty());
	}

}
