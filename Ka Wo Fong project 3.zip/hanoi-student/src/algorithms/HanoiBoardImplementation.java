package algorithms;

import java.util.Stack;

import hanoi.HanoiBoard;
import hanoi.HanoiMove;
import hanoi.HanoiRing;
import hanoi.IllegalHanoiMoveException;

public class HanoiBoardImplementation implements HanoiBoard 
{
	protected HanoiPegImplementation peg1, peg2, peg0; 
	protected int numRing; 
	
	public HanoiBoardImplementation ()
	{
		peg0 = new HanoiPegImplementation () ;
		peg1 = new HanoiPegImplementation () ;
		peg2 = new HanoiPegImplementation () ;
		numRing = 0; 
	}
	
	
	@Override
	public void doMove(HanoiMove move) 
	{
		if (!isLegalMove(move))
			throw new IllegalHanoiMoveException ("Illegal move!"); 

		switch (move.getFromPeg())
		{
			case 0:		this.designatePeg(move.getToPeg()).addRing(peg0.remove()); 
						break; 
			case 1:		this.designatePeg(move.getToPeg()).addRing(peg1.remove()); 
						break; 
			
			case 2:		this.designatePeg(move.getToPeg()).addRing(peg2.remove()); 
						break; 		
		}

	}

	@Override
	public void setup(int n) 
	{
		numRing = n; 
		if (n < 0)
			throw new IllegalArgumentException ("Cannot place a negative value of rings!"); 
		else 
		{
			for (int i = n; i > 0; i--)
				peg0.addRing(new HanoiRing(i)); 
			peg1 = new HanoiPegImplementation () ;
			peg2 = new HanoiPegImplementation () ; 
		}

	}

	@Override
	public boolean isSolved() 
	{
		boolean isFlag = true; 
		Stack<HanoiRing> temp = new Stack<HanoiRing> ();
		int counter = 0; 
		while (peg2.hasRings())
		{
			if (!(temp.empty()))
				if (temp.peek().getSize() > peg2.getTopRing().getSize())
					isFlag = false; 
			temp.push(peg2.remove()); 
			counter++;
		}
		while (!(temp.empty()))
			peg2.addRing(temp.pop());
		if (counter != numRing)
			isFlag = false; 
		
		return isFlag;
	}

	@Override
	public boolean isLegalMove(HanoiMove move) 
	{
		if (move == null)
			throw new NullPointerException ("Invalid move!"); 
		HanoiPegImplementation toPeg, fromPeg; 
		boolean isFlag = true; 
		toPeg = this.designatePeg(move.getToPeg());
		fromPeg = this.designatePeg(move.getFromPeg());
		if (toPeg == fromPeg)
			return false;
		if (!(fromPeg.hasRings()))
			return false; 
		if (toPeg.hasRings() && toPeg.getTopRing().getSize() < fromPeg.getTopRing().getSize())	
			isFlag = false; 
		return isFlag; 
	}


	private HanoiPegImplementation designatePeg(int i) // Finding specific peg based on its number
	{
		HanoiPegImplementation peg = null; 
		switch (i)
		{
			case 0:		peg = peg0;
						break; 
			case 1:		peg = peg1;
						break;
			case 2:		peg = peg2; 
						break; 
		}
		return peg;
		
	}	
}
