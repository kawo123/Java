package algorithms;

import structures.ListInterface;

public class UnboundList<T> implements ListInterface<T> 
{
	private static int listSize; 
	protected ListNode<T> head; 
	protected ListNode<T> tail;
	
	public UnboundList ()
	{
		listSize = 0; 
		head = null;
		tail = null; 
	}
	
	@Override
	public int size() 
	{
		return listSize;
	}
	
	public T getTail ()
	{
		return tail.getInfo(); 
	}
	
	@Override
	public ListInterface<T> append(T elem) 
	{
		ListNode<T> temp = new ListNode<T> (elem); 
		
		if (elem == null)
			throw new NullPointerException ("Element is null!"); 
		if (this.size() == 0)
		{
			head = temp; 
			tail = temp;
		}
		else 
		{
			tail.setLink(temp);
			tail = temp; 
		}
		listSize++; 
		return this;
	}

	@Override
	public T remove (int n) 
	{
		ListNode<T> curr = head ; 
		ListNode<T> hold = head; 
		if (n<0 || n>=this.size())
			throw new IndexOutOfBoundsException ("Invalid index!"); 
		if (size() == 0)
			throw new NullPointerException ("List is empty!"); 
		if (size() == 1)
		{
			head = null; 
			tail = null;
		}
		else  
			if(n == 0)	
				head = head.getLink();
			else 
				if (size() == 2 && n == 1)
				{
					hold = tail; 
					tail = head; 
				}
				else 
				{
					
					for (int i =0; i<n; i++ )
						hold = hold.getLink(); 
					for (int i=0; i<n-1; i++)
						curr = curr.getLink(); 
					if (n == size()-1)
					{
						curr.setLink(null);
						tail = curr; 
					}
					else 	
						curr.setLink(curr.getLink().getLink());
				}
		
		
		
		listSize--; 
		return hold.getInfo();

	}

}
