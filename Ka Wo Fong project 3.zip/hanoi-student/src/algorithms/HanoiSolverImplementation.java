package algorithms;

import structures.ListInterface;
import hanoi.HanoiMove;
import hanoi.HanoiSolution;
import hanoi.HanoiSolver;

public class HanoiSolverImplementation implements HanoiSolver 
{
	HanoiSolutionImplementation solution; 
	HanoiBoardImplementation gameBoard; 
	UnboundList<HanoiMove> listMoves; 
	
	public  HanoiSolverImplementation ()
	{
		gameBoard = new HanoiBoardImplementation (); 
		listMoves = new UnboundList<HanoiMove> (); 
	}
	
	@Override
	public HanoiSolution solve(int n) 
	{
		
		gameBoard.setup(n); 
		
		if (n < 0)
			throw new IllegalArgumentException ("Cannot have negative rings!");
		else 
			solveHanoiHelper(n, 0, 1, 2); // 0 = starting peg, 1 = auxillary peg, 2 = ending peg
		solution = new HanoiSolutionImplementation (n, listMoves);
		return solution; 
			
	}
	
	private void solveHanoiHelper (int n, int start, int aux, int end)
	{
		if (n>0)
		{
			solveHanoiHelper(n-1, start, end, aux);
			HanoiMove temp = new HanoiMove (start,end);
			listMoves.append(temp); 
			gameBoard.doMove(temp);
			solveHanoiHelper(n-1, aux, start, end);
		}		
	}
}
