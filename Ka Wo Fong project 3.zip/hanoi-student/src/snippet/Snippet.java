package snippet;

public class Snippet {
	public static void main(String[] args) 
	{
		int n=0; 
		if (n < 0)
					throw new IllegalArgumentException("Input must be greater than 0.");
	}
}

