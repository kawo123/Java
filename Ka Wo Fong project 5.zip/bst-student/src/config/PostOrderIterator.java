package config;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

import structures.BinaryTreeNode;

//Adopted from PreOrderIterator.java and Stanley Lok has helped me

public class PostOrderIterator<T> implements Iterator<T> 
{
	private Deque<BinaryTreeNode<T>> stack = new LinkedList<BinaryTreeNode<T>>(); 
	BinaryTreeNode<T> root, lastPop;  
		
	public PostOrderIterator(BinaryTreeNode<T> root)
	{
		this.root = root;
		stack.push(root);
		while (root.hasLeftChild())
		{
			root = root.getLeftChild();
			stack.push(root); 
		}
	}
	
	

	@Override
	public boolean hasNext() {
		return !stack.isEmpty();
	}

	@Override
	public T next() 
	{
		BinaryTreeNode<T> toVisit = stack.peek(); 
		T info;  
		if(toVisit.hasRightChild()) 
		{
			if (toVisit.getRightChild()!=lastPop)
			{
				stack.push(toVisit.getRightChild());
				toVisit = toVisit.getRightChild();
				while (toVisit.hasLeftChild())
				{
					if (toVisit.getLeftChild()!= lastPop)
						stack.push(toVisit.getLeftChild());
					toVisit = toVisit.getLeftChild(); 
				}
			}
		}
		lastPop = stack.peek(); 
		info = stack.pop().getData(); 
			
		return info; 
	}
	
	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	
}
