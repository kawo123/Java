package config;

import java.util.Iterator;

import structures.BinaryTreeNode;
import structures.BinaryTreeUtility;
import structures.PreOrderIterator;

public class BTUtility<T> implements BinaryTreeUtility 
{


	
	@Override
	public <T> Iterator<T> getPreOrderIterator(BinaryTreeNode<T> root) 
	{
		if (root == null)
			throw new NullPointerException ("The root has not been initialized yet!"); 
		// TODO Auto-generated method stub
		else 
			return new PreOrderIterator<T>(root);
	}

	@Override
	public <T> Iterator<T> getInOrderIterator(BinaryTreeNode<T> root) 
	{
		// TODO Auto-generated method stub
		if (root == null)
			throw new NullPointerException ("The root has not been initialized yet!"); 
		else 	
			return new InOrderIterator<T>(root);
	}

	@Override
	public <T> Iterator<T> getPostOrderIterator(BinaryTreeNode<T> root) 
	{
		// TODO Auto-generated method stub
		if (root == null)
			throw new NullPointerException ("The root has not been initialized yet!"); 
		return new PostOrderIterator<T>(root);
	}

	
//  getDepth method below is adopted from 
//	http://tekmarathon.com/2013/05/02/find-depth-of-binary-search-tree/
	
	@Override
	public <T> int getDepth(BinaryTreeNode<T> root) {

		if (root == null)
			throw new NullPointerException("Root has not been initialized yet");
		if (!root.hasLeftChild() && !root.hasRightChild())
			return 0; 
		else 
		{
			int leftDepth = 0, rightDepth = 0; 
			if (root.hasLeftChild())
				leftDepth = getDepth(root.getLeftChild()); 
			if (root.hasRightChild())
				rightDepth = getDepth(root.getRightChild());
			if (leftDepth > rightDepth)
				return (leftDepth + 1);
			else 
				return (rightDepth + 1); 
		}
	}

	
	@Override
	public <T> boolean isBalanced(BinaryTreeNode<T> root, int tolerance) 
	{
		int leftDepth = 0, rightDepth = 0; 
		boolean isBalanced = true; 
		if (root == null)
			throw new NullPointerException ("Tree has not been initialized yet"); 
		if (tolerance < 0)
			throw new IllegalArgumentException ("Tolerance must be greater than or equal to 0");
		if (!root.hasLeftChild() && !root.hasRightChild())
			return true; 
		if (root.hasLeftChild())
		{
			isBalanced = isBalanced(root.getLeftChild(), tolerance); 
			leftDepth = getDepth(root.getLeftChild()) + 1;  
		}
		if (root.hasRightChild())
		{
			isBalanced = isBalanced(root.getRightChild(), tolerance);
			rightDepth = getDepth(root.getRightChild()) + 1; 
		}
		if (Math.abs(leftDepth - rightDepth) > tolerance)
			return false; 
		return isBalanced;
	}
	
//	public boolean checkBalance (BinaryTreeNode<T> root, int tolerance)
//	{
//		return 
//	}

	@Override
	public <T extends Comparable<? super T>> boolean isBST(BinaryTreeNode<T> root)
	{
		boolean isValid = true; 
		
		if (root == null)
			throw new NullPointerException("Root has not been initialized yet");
		if (!root.hasLeftChild() && !root.hasRightChild())
			return true; 
		
		if (root.hasLeftChild())
			if(root.getLeftChild().getData().compareTo(root.getData()) > 0)
				return false; 
			else 
				isValid = isBST (root.getLeftChild());
		if (root.hasRightChild())
			if(root.getRightChild().getData().compareTo(root.getData()) < 0)
				return false; 
			else	
				isValid = isBST (root.getRightChild());
		
		return isValid;
	}

}
