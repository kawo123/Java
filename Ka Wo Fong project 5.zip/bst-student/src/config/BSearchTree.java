package config;

import java.util.Iterator;

import structures.BinarySearchTree;
import structures.BinaryTreeNode;

// All methods are adapted from Lecture notes and textbook 
// Received help from StackOverFlow and Stanley Lok


public class BSearchTree<T extends Comparable<? super T>> implements BinarySearchTree<T> 
{

	protected BLLNode<T> root; 
	boolean found; 
	
	
	public BSearchTree ()
	{
		root = null; 
	}
	
	public BSearchTree (BLLNode<T> root)
	{
		this.root = root; 
	}
	
	@Override
	public BinarySearchTree<T> add(T toAdd) 
	{
		if (toAdd == null)
			throw new NullPointerException ("The element is null!"); 
		else 
		{
			root = recAdd(toAdd, root); 
			return this;
		}
	}
	
	private BLLNode<T> recAdd (T toAdd, BinaryTreeNode<T> tree)
	{
		
		if (tree == null)
			tree = new BLLNode<T> (null, toAdd, null);
			
		else 
			if (((Comparable) toAdd).compareTo(tree.getData()) <= 0)
			{	
				if (!tree.hasLeftChild())
					tree.setLeftChild(new BLLNode<T>(null, toAdd, null)); 
				else 
					tree.setLeftChild(recAdd(toAdd, tree.getLeftChild()));
			}
			else 
				if (!tree.hasRightChild())
					tree.setRightChild(new BLLNode<T>(null, toAdd, null));
				else
					tree.setRightChild(recAdd(toAdd, tree.getRightChild()));
		return (BLLNode<T>) tree; 
		
	}

	@Override
	public boolean contains(T toFind) {
		if (toFind == null)
			throw new NullPointerException("The element is null!"); 
		else 
			return recContains(toFind, root);
	}

	private boolean recContains (T toFind, BinaryTreeNode<T> tree)
	{
		if (tree == null)
			return false;
		
		if (((Comparable) toFind).compareTo(tree.getData()) < 0)
			if (tree.hasLeftChild())
				return recContains(toFind, tree.getLeftChild());
		if (((Comparable) toFind).compareTo(tree.getData()) > 0)
			if (tree.hasRightChild())	
				return recContains(toFind, tree.getRightChild());
		if (((Comparable) toFind).compareTo(tree.getData()) == 0)
			return true; 
		return false; 
	}
	
	@Override
	public boolean remove(T toRemove) {
		// TODO Auto-generated method stub
		found = false; 
		root = recRemove(toRemove, root); 
		return found;
	}

	private BLLNode<T> recRemove (T toRemove, BinaryTreeNode<T> tree)
	{
		if (tree == null)
			found = false; 
		else 
			if (((Comparable) toRemove).compareTo(tree.getData()) < 0)
			{	
				if (tree.hasLeftChild())	
					tree.setLeftChild(recRemove(toRemove, tree.getLeftChild()));
			}
			else 
				if (((Comparable) toRemove).compareTo(tree.getData()) > 0)
				{	
					if (tree.hasRightChild())	
						tree.setRightChild(recRemove(toRemove, tree.getRightChild()));
				}
				else 
				{
					tree = removeNode(tree); 
					found = true;
				}
		return (BLLNode<T>) tree;
					
	}
	
	private BLLNode<T> removeNode (BinaryTreeNode<T> tree)
	{
		T info; 
		if (!tree.hasLeftChild() && !tree.hasRightChild())
			return null; 
		if (!tree.hasLeftChild())
			return (BLLNode<T>) tree.getRightChild(); 
		else
			if (!tree.hasRightChild())
				return (BLLNode<T>) tree.getLeftChild(); 
			else
			{	
				info = getPredecessor (tree.getLeftChild()); 
				tree.setData(info);
				tree.setLeftChild(recRemove(info, tree.getLeftChild())); 
				return (BLLNode<T>) tree; 
			}
	}
	
	private T getPredecessor (BinaryTreeNode<T> tree)
	{
		while (tree.hasRightChild())
			tree = (BLLNode<T>) tree.getRightChild();
		return tree.getData(); 
	}
		
	@Override
	public int size() 
	{
		return recSize(root);
	}

	private int recSize(BinaryTreeNode<T> tree)
	{
		if (tree == null)
			return 0; 
		if (!tree.hasLeftChild() && !tree.hasRightChild())
			return 1; 
		else if (tree.hasLeftChild() && tree.hasRightChild())
				return recSize (tree.getLeftChild())+recSize(tree.getRightChild()) + 1; 
		else if (tree.hasLeftChild())
				return recSize(tree.getLeftChild()) + 1 ; 
		else 
			return recSize(tree.getRightChild()) + 1 ;
			
		
	}
	
	@Override
	public boolean isEmpty() 
	{
		return (root == null);
	}

	@Override
	public T getMinimum() 
	{
		if (isEmpty())
			throw new IllegalStateException("The tree is empty!"); 
		else
		{
			BinaryTreeNode<T> hold = root; 
			while (hold.hasLeftChild())
				hold = hold.getLeftChild(); 
			return hold.getData(); 
		}
	}

	@Override
	public T getMaximum() 
	{
		if (isEmpty())
			throw new IllegalStateException("The tree is empty!"); 
		else
		{
			BinaryTreeNode<T> hold = root; 
			while (hold.hasRightChild())
				hold = hold.getRightChild(); 
			return hold.getData(); 
		}
	}

	@Override
	public BinaryTreeNode<T> toBinaryTreeNode() 
	{
		if (isEmpty())
			throw new IllegalStateException("The tree is empty!"); 
		else
			return root;
	}

	@Override
	public Iterator<T> iterator() 
	{
		return new InOrderIterator<T> (root);
	}

}
