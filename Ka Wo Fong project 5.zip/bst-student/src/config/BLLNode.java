package config;

import structures.BinaryTreeNode;

public class BLLNode<T> implements BinaryTreeNode<T> {

	BLLNode<T> right; 
	BLLNode<T> left; 
	T data; 
	
	public BLLNode (BinaryTreeNode<T> left, T info, BinaryTreeNode<T> right)
	{
		this.right = (BLLNode<T>) right; 
		this.left = (BLLNode<T>) left; 
		data = info; 
	}
	
	@Override
	public T getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public void setData(T data) {
		if (data == null)
			throw new NullPointerException ("Data is null"); 
		else
			this.data = data; 

	}

	@Override
	public boolean hasLeftChild() {
		// TODO Auto-generated method stub
		return !(left == null);
	}

	@Override
	public boolean hasRightChild() {
		// TODO Auto-generated method stub
		return !(right == null);
	}

	@Override
	public BinaryTreeNode<T> getLeftChild() {
		// TODO Auto-generated method stub
		if (hasLeftChild())
			return left;
		else 
			throw new IllegalStateException("There is no left child");
	}

	@Override
	public BinaryTreeNode<T> getRightChild() {
		// TODO Auto-generated method stub
		if (hasRightChild())
			return right;
		else 
			throw new IllegalStateException("There is no right child");
	}

	@Override
	public void setLeftChild(BinaryTreeNode<T> left) {
		// TODO Auto-generated method stub
		this.left = (BLLNode<T>) left; 
	}

	@Override
	public void setRightChild(BinaryTreeNode<T> right) 
	{
		// TODO Auto-generated method stub
		this.right = (BLLNode<T>) right; 
	}

}
