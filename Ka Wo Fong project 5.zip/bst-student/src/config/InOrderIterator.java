package config;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import structures.BinaryTreeNode;
// Adopted from PreOrderIterator.java and http://stackoverflow.com/questions/12850889/in-order-iterator-for-binary-tree


public class InOrderIterator<T> implements Iterator<T> 
{
	private Deque<BinaryTreeNode<T>> stack = new LinkedList<BinaryTreeNode<T>>(); 
	BinaryTreeNode<T> root;  
	
	private void pushLeftChild(BinaryTreeNode<T> node)
	{
		while (node.hasLeftChild())
		{
			node = node.getLeftChild();
			stack.push(node); 
		}
	}
	
	public InOrderIterator(BinaryTreeNode<T> root)
	{
		this.root = root;
		stack.push(root);
		pushLeftChild(root); 
	}
	
	

	@Override
	public boolean hasNext() {
		return !stack.isEmpty();
	}

	@Override
	public T next() 
	{
		BinaryTreeNode<T> toVisit; 
		T info; 
		toVisit = stack.pop(); 
		info = toVisit.getData(); 
		if(toVisit.hasRightChild()) 
		{
			stack.push(toVisit.getRightChild());
			toVisit = toVisit.getRightChild(); 
			pushLeftChild(toVisit); 
		}
			
		return info; 
	}
	
	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
