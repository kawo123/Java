package evaluator.arith;

import language.Operand;
import language.Operator;
import parser.arith.ArithPostFixParser;
import stack.LinkedStack;
import stack.StackInterface;
import evaluator.IllegalPostFixExpressionException;
import evaluator.PostFixEvaluator;

/**
 * An {@link ArithPostFixEvaluator} is a post fix evaluator over simple arithmetic expressions.
 *
 */
public class ArithPostFixEvaluator implements PostFixEvaluator<Integer> 
{

	private final StackInterface<Operand<Integer>> stack;
	
	/**
	 * Constructs an {@link ArithPostFixEvaluator}
	 */
	public ArithPostFixEvaluator()
	{
		this.stack = new LinkedStack<Operand<Integer>> (); //TODO Initialize to your LinkedStack
		
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Integer evaluate(String expr) throws IllegalPostFixExpressionException
	{
		// TODO Use all of the things they've built so far to 
		// create the algorithm to do post fix evaluation

		Integer result = new Integer (0);
		
		ArithPostFixParser parser = new ArithPostFixParser(expr);
		while(parser.hasNext())
		{
			switch(parser.nextType())
			{ 
				case OPERAND:
					stack.push(parser.nextOperand());
				break;
				
				case OPERATOR:
					Operator<Integer> op = parser.nextOperator(); 
					if (op.getNumberOfArguments()==2)
					{
						op.setOperand(1,stack.pop());
						op.setOperand(0,stack.pop());
					}
					else
					{
						if (op.getNumberOfArguments()==1)
							op.setOperand(0,stack.pop());
					}
					stack.push(op.performOperation()); 
				break;
			}
		}
		
		result = stack.pop().getValue();

		if (stack.isEmpty())
			return result;
		else 
			throw new IllegalPostFixExpressionException ("This expression does not work!"); 
	}

	
}
