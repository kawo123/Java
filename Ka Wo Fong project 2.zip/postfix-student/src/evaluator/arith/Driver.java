package evaluator.arith;

import java.util.Scanner;

import evaluator.PostFixEvaluator;




public class Driver 
{

	public static void main(String[] args) 
	{
	
		Scanner s = new Scanner(System.in);
		PostFixEvaluator<Integer> evaluator = new ArithPostFixEvaluator();
		System.out.println("Welcome to the Post Fix Evaluator 5000 SUX");
		System.out.println("Please enter a post fix expression to be evaluated:");
		String expr = s.nextLine();
		//SometimesIgetanexceptionMaybeIshoulduseatry/catchblock.
		Integer result = evaluator.evaluate(expr);
		System.out.println("The expression evaluated to: "+ result);
		//MaybeIcouldaskuseriftheywanttoenteranotherexpressionandloop
			
 
		

	}

}
