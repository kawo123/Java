package stack;

//Copied from DJW's implementation of LLNode class from the book

public class Node<T> 
{
	private Node link; 
	private T info; 
	
	public Node (T info)
	{
		this.info = info;
		link = null; 
	}
	
	public void setInfo(T info)
	{
		this.info = info;
	}
	public T getInfo()
	{
		return info;
	}
	public void setLink (Node link)
	{
		this.link = link;
	}
	public Node getLink ()
	{
		return link; 
	}
	
	
}
