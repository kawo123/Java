package stack;

/**
 * A {@link LinkedStack} is a stack that is implemented using a Linked List structure
 * to allow for unbounded size.
 *
 * @param <T> the elements stored in the stack
 */
public class LinkedStack<T> implements StackInterface<T> 
{

	protected Node<T> top;
	protected Node<T> node; 
	
	public LinkedStack ()
	{
		top = null;
		node = null; 
	}
	

	@Override
	public T pop() throws StackUnderflowException 
	{
		node = top; 
		if (isEmpty())
			throw new StackUnderflowException ("Stack is Empty");
		else 
			top = top.getLink(); 
			
		return node.getInfo();
	}


	@Override
	public T top() throws StackUnderflowException 
	{
		// TODO Auto-generated method stub

		if (isEmpty())
			throw new StackUnderflowException ("Stack is Empty");
		else 
			return top.getInfo();
	}


	@Override
	public boolean isEmpty() 
	{
		return (top == null);
	}


	@Override
	public int size() 
	{
		int size = 0; 
		node = top;
		while (node != null)
		{
			size++;
			node = node.getLink();
		}
		return size;
	}


	@Override
	public void push(T elem) 
	{
		Node<T> temp = new Node<T> (elem);
		temp.setLink(top); 
		top = temp; 
		
	}

}
