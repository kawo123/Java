package hangman;

public class GameBoardLinkedList implements GameBoard, HangManConstants 
{
	
	private int	state;
	
	private LLCharacterNode guessWordLinkedList; 
	private LLCharacterNode displayWordLinkedList; 
	private LLCharacterNode letterGuessedLinkedList; 
	private LLCharacterNode letterGuessedNode; 
	private LLCharacterNode guessWordNode;
	private LLCharacterNode displayWordNode; 
	private int numGuesses; 



	public GameBoardLinkedList (String guessWord)
	{
		state    = STARTING_STATE;
		numGuesses=0;
		letterGuessedLinkedList = new LLCharacterNode ();
		guessWordLinkedList = new LLCharacterNode (guessWord.charAt(guessWord.length()-1));
		displayWordLinkedList = new LLCharacterNode ('_');
		for (int i=guessWord.length()-2; i>=0; i--)
		{
			LLCharacterNode guessWordNode = new LLCharacterNode (guessWord.charAt(i));
			LLCharacterNode displayWordNode = new LLCharacterNode ('_');
			guessWordNode.setLink(guessWordLinkedList);
			guessWordLinkedList = guessWordNode; 
			displayWordNode.setLink(displayWordLinkedList); 
			displayWordLinkedList = displayWordNode; 
		}	
	}
	

	public boolean isPriorGuess(char guess) 
	{
		letterGuessedNode = letterGuessedLinkedList;
		while (letterGuessedNode!=null)
		{
			if(letterGuessedNode.getInfo() == guess)
				return true;
			else
				letterGuessedNode = letterGuessedNode.getLink();
		}
		
		return false;
	}

	public int numberOfGuesses() 
	{

		return numGuesses;
	}

	
	public boolean isCorrectGuess(char guess) 
	{
		guessWordNode = guessWordLinkedList; 
		boolean isCorrect = false; 
		
		if(!isPriorGuess(guess))
		{
			while (guessWordNode!=null)
			{
				if (guessWordNode.getInfo() == guess)
				{ 
					isCorrect = true; 
				}
				guessWordNode = guessWordNode.getLink();  
			}
			
		}
		return isCorrect;
	}


	public boolean doMove(char guess) 
	{
		int letterGuessedIndex = -1; 
		boolean flag = false; 
		guessWordNode = guessWordLinkedList; 
		displayWordNode = displayWordLinkedList; 
		
		if (isPriorGuess(guess))
			return false;

		while (guessWordNode != null)
		{
			displayWordNode = displayWordLinkedList;
			letterGuessedIndex++;
			if (guessWordNode.getInfo()==guess)
			{
				for (int i=0; i < letterGuessedIndex; i++ )
					displayWordNode = displayWordNode.getLink();
				displayWordNode.setInfo(guess);
				flag = true; 
			}
			guessWordNode = guessWordNode.getLink(); 
		}
		letterGuessedNode = letterGuessedLinkedList;
		if (numGuesses != 0)
			while (letterGuessedNode.getLink()!=null)
				letterGuessedNode = letterGuessedNode.getLink(); 
		letterGuessedNode.setLink(new LLCharacterNode(guess));
		
		numGuesses++;
		
		if (!flag)
		{
			state++;
			return false; 
		}
			
		else 
			return true;

	}


	public boolean inWinningState() 
	{
		boolean isWinning = false; 
		guessWordNode = guessWordLinkedList; 
		displayWordNode = displayWordLinkedList; 
		while (guessWordNode != null)
		{
			if (guessWordNode.getInfo() == displayWordNode.getInfo())
			{
				isWinning=true; 
			}
			else 
			{
				return false;
			}
			guessWordNode = guessWordNode.getLink();
			displayWordNode = displayWordNode.getLink(); 
		}
			
		return isWinning;
	}

	
	public boolean inLosingState() 
	{
		return state == NUMBER_OF_STATES;
	}

	
	public int currentHungState() 
	{
		return state;
	}

	
	public String previousGuessString() 
	{
		String s = new String();
		letterGuessedNode = letterGuessedLinkedList; 

		while (letterGuessedNode != null)
		{
			s = s + ", " + letterGuessedNode.getInfo();
			letterGuessedNode = letterGuessedNode.getLink();
		}
		s = s.substring(5);
		s = "[" + s + "]";
		return s;
	}
	
	public String toString()
	{
		String s = new String();
		displayWordNode = displayWordLinkedList; 
		s += displayWordNode.getInfo();
		displayWordNode = displayWordNode.getLink(); 
		while(displayWordNode != null)
		{
			s = s + " " + displayWordNode.getInfo();
			displayWordNode = displayWordNode.getLink(); 
		}
		return s;
	}
	
}
