package hangman;

import java.util.Arrays;

/**
 * The Array implementation of the GameBoard interface.
 */
public class GameBoardArray implements GameBoard, HangManConstants 
{
	
	/** The number of characters (lower/upper). 
	private static int ALPHABET_COUNT = 26*2; */
	
	/** hung state */
	private int	state;
	
	private char guessWordArray []; 
	private char displayWordArray[]; 
	private char letterGuessed []; 
	private int numGuesses; 
	
	/**
	 * Creates a new GameBoardArray object.
	 * 
	 *  guessWord the word to guess
	 */
	public GameBoardArray(String guessWord) // TODO (1)
	{
		state    = STARTING_STATE;
		numGuesses=0;
		letterGuessed = new char [guessWord.length()+NUMBER_OF_STATES];
		guessWordArray = new char [guessWord.length()];
		displayWordArray = new char [guessWord.length()];
		for (int i=0; i<guessWord.length(); i++)
		{
			guessWordArray[i] = guessWord.charAt(i);
			displayWordArray[i] = '_';
		}	
		
	}
	
	
	public boolean isPriorGuess(char guess) // TODO (2)
	{
		for (int i=0; i<letterGuessed.length; i++)
		{
			if (letterGuessed[i]==guess)
				return true;
		}
		return false;	
	}
	
	
	public int numberOfGuesses() //TODO3
	{
		return numGuesses;
	}
	
	
	public boolean isCorrectGuess(char guess) // TODO (4)
	{
		if(!isPriorGuess(guess))
		{
			for (int i=0; i<guessWordArray.length; i++)
			{
				if(guessWordArray[i]==guess)
				{
					return true;
				}
			}
		}
			
		return false;
	}
	
	
	public boolean doMove(char guess) // TODO (5)
	{
		boolean flag = false; 
		
		if (isPriorGuess(guess))
			return flag;

		for (int i=0; i<guessWordArray.length; i++)
		{
			if(guessWordArray[i]==guess)
			{
				displayWordArray[i]=guess;
				flag = true;
			}
		}
				
		letterGuessed[numGuesses] = guess; 
		numGuesses++;
		
		if (!flag)
		{
			state++;
			return false; 
		}
			
		else 
			return true;

	}

	
	public boolean inWinningState() // TODO (6)
	{
		if (Arrays.equals(guessWordArray, displayWordArray))
			return true;
		else
			return false;
	}

	
	public boolean inLosingState() 
	{
		return state == NUMBER_OF_STATES;
	}
	
	
	public String toString() // TODO (7)
	{
		String s = new String(); ;
		s += displayWordArray[0]; 
		for (int i=1; i<displayWordArray.length; i++)
		{
			s = s + " " + displayWordArray[i]; 
		}
		return s;
	}

	
	public String previousGuessString() // TODO (8)
	{
		String s = "[";
		
			for (int i=0; i<numGuesses; i++)
			{
				if(i==0)
				{
					s = s+ letterGuessed[0];
				}
				else 
				{
					s = s + ", " + letterGuessed[i]; 
				}
			} 
			s = s + "]";
		
		return s;
	}
	
	
	public int currentHungState() 
	{
		return state;
	}

}
