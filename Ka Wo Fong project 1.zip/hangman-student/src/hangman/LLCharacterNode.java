package hangman;

public class LLCharacterNode 
{
	
	private char character; 
	private LLCharacterNode link; 
	
	public LLCharacterNode ()
	{
		link = null;  
	}
	
	public LLCharacterNode (char character)
	{
		this.character = character;
		link = null; 
	}
	
	public void setInfo (char character)
	{
		this.character = character;
	}
	
	public char getInfo()
	{
		return character;
	}
	
	public void setLink (LLCharacterNode link)
	{
		this.link = link; 
	}
	
	public LLCharacterNode getLink()
	{
		return link;
	}
	
	
}
